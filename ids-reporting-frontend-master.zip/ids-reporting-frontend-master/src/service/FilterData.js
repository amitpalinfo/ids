import axios from "axios";
import { API_URL } from "./Const";



export const FilterData = (
  countryData,
  industryDataFilter,
  subindustryDataFilter,
  activityDataFilter,
  companySizeDataFilter,
  departmentDataFilter,
  seniorityDataFilter,
  domain,
  std
) => {

  console.log("mm",industryDataFilter)


  // Get Country Array
  const countryArray = countryData
    .filter((aar) => aar.value.COUNTRY)
    .map((c) => c.value)
    .filter(
      (obj, index, self) =>
        index === self.findIndex((t) => t.COUNTRY === obj.COUNTRY) &&
        obj.COUNTRY
    )
    .map((r) => r.COUNTRY);

  // Get State Array
  const stateArray = countryData
    .filter((aar) => aar.value.STATE)
    .map((c) => c.value)
    .filter(
      (obj, index, self) =>
        index === self.findIndex((t) => t.STATE === obj.STATE) && obj.STATE
    )
    .map((r) => r.STATE);

  // Get City Array
  const cityArray = countryData
    .filter((aar) => aar.value.CITY)
    .map((c) => c.value)
    .filter(
      (obj, index, self) =>
        index === self.findIndex((t) => t.CITY === obj.CITY) && obj.CITY
    )
    .map((r) => r.CITY);

  const filters = [
    {
      type: "SUB_VERTICAL[]",
      values: subindustryDataFilter,
    },
    {
      type: "VERTICAL[]",
      values: industryDataFilter,
    },
    {
      type: "ACTIVITY_TYPE[]",
      values: activityDataFilter,
    },
    {
      type: "COUNTRY[]",
      values: countryArray,
    },
    {
      type: "STATE[]",
      values: stateArray,
    },
    {
      type: "CITY[]",
      values: cityArray,
    },
    {
      type: "TOTAL_EMPLOYEE_COUNT[]",
      values: companySizeDataFilter,
    },
    {
      type: "DEPARTMENT[]",
      values: departmentDataFilter,
    },
    {
      type: "JOB[]",
      values: seniorityDataFilter,
    },
    {
      type: "DOMAIN[]",
      values: domain,
    },
    {
      type: "STD[]",
      values: [std],
    },
  ];

  const queryParamss = new URLSearchParams();
  filters.forEach((item) => {
    item.values.forEach((value) => {
      queryParamss.append(item.type, value);
    });
  });
  const url = `${API_URL}/get_filter_data?${queryParamss.toString()}`;

  const fetchData = async () => {
    try {
      const response = await axios.get(url);

      return response.data;
    } catch (error) {
      console.error(error);
    }
  };



  return fetchData();
};
