import { configureStore,getDefaultMiddleware } from '@reduxjs/toolkit';
import { rootslice } from './rootSlices';


const middleware = [...getDefaultMiddleware({
  serializableCheck: false,
})];

export const store = configureStore({
  reducer: rootslice,
  middleware
})