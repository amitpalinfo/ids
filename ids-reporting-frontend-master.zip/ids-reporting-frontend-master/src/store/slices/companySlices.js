import { createSlice } from "@reduxjs/toolkit";

let initialState = {
  apiData: [],
  filterData: [],
  countryData: [],
  industryDataFilter: [],
  subindustryDataFilter: [],
  activityDataFilter: [],
  companySizeDataFilter: [],
  departmentDataFilter: [],
  seniorityDataFilter: [],
  overviewData: [],
  applyfilter: false,
  userdata: "",
  domain: [],
  std: false,
  loader: false,
  filterApply:false

  // current_user: [],
  // enrolled_courses: [],
};
export const CompanySlice = createSlice({
  name: "company",
  initialState,
  reducers: {
    allApiData: (state, action) => {
      state.apiData = action.payload;
    },

    filterCompanyData: (state, action) => {
      state.filterData = action.payload;
    },

    countryFilterSelected: (state, action) => {
      state.countryData = action.payload;
    },
    industryFilterSelected: (state, action) => {
      state.industryDataFilter = action.payload;
    },
    subindustryFilterSelected: (state, action) => {
      state.subindustryDataFilter = action.payload;
    },
    activityFilterSelected: (state, action) => {
      state.activityDataFilter = action.payload;
    },
    companySizeFilterSelected: (state, action) => {
      state.companySizeDataFilter = action.payload;
    },
    departmentFilterSelected: (state, action) => {
      state.departmentDataFilter = action.payload;
    },
    seniorityFilterSelected: (state, action) => {
      state.seniorityDataFilter = action.payload;
    },
    overviewFilterSelected: (state, action) => {
      state.overviewData = action.payload;
    },
    applyfilterSelected: (state, action) => {
      state.applyfilter = action.payload;
    },

    userdataGet: (state, action) => {
      state.userdata = action.payload;
    },
    domainselected: (state, action) => {
      state.domain = action.payload;
    },

    stdselected: (state, action) => {
      state.std = action.payload;
    },
    loaderselected: (state, action) => {
      state.loader = action.payload;
    },
    filterApplySelected:(state, action) => {
      state.filterApply = action.payload;
    },

    resetAll: (state, payload) => {
      state.countryData = [];
      state.filterData = [];
      state.seniorityDataFilter = [];
      state.departmentDataFilter = [];
      state.companySizeDataFilter = [];
      state.subindustryDataFilter = [];
      state.activityDataFilter = [];
      state.industryDataFilter = [];
      state.overviewData = [];
      state.domain = [];
      state.std = false;
      state.loader = false;
      state.filterApply=false
    },

    allFilterData: (state, action) => {},
  },
});
export const {
  allApiData,
  filterCompanyData,
  countryFilterSelected,
  industryFilterSelected,
  subindustryFilterSelected,
  allFilterData,
  activityFilterSelected,
  companySizeFilterSelected,
  departmentFilterSelected,
  seniorityFilterSelected,
  resetAll,
  overviewFilterSelected,
  applyfilterSelected,
  userdataGet,
  domainselected,
  stdselected,
  loaderselected,
  filterApplySelected
} = CompanySlice.actions;
export default CompanySlice.reducer;
