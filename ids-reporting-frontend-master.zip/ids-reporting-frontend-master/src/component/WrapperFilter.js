import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import {
  countryFilterSelected,
  industryFilterSelected,
  subindustryFilterSelected,
  activityFilterSelected,
  companySizeFilterSelected,
  departmentFilterSelected,
  seniorityFilterSelected,
  domainselected,
  resetAll,
  applyfilterSelected
} from "../store/slices/companySlices";
export default function WrapperFilter() {
  const dispatch = useDispatch();
  const [allFilter, SetAllFilter] = useState([]);
  const {
    countryData,
    industryDataFilter,
    subindustryDataFilter,
    activityDataFilter,
    companySizeDataFilter,
    departmentDataFilter,
    seniorityDataFilter,
    domain,
  } = useSelector((state) => state.denave);

  useEffect(() => {
    const mergeFilter = [
      ...countryData.map((e) => e.label),
      ...industryDataFilter,
      ...subindustryDataFilter,
      ...activityDataFilter,
      ...companySizeDataFilter,
      ...departmentDataFilter,
      ...seniorityDataFilter,
      ...domain,
    ];
    SetAllFilter(mergeFilter);
  }, [
    countryData,
    industryDataFilter,
    subindustryDataFilter,
    activityDataFilter,
    companySizeDataFilter,
    departmentDataFilter,
    seniorityDataFilter,
    domain,
  ]);

  const removeFilter = (name) => {
    let checkCountryArr = countryData.some((array) =>
      array.label.includes(name)
    );
    let checkIndustryArr = industryDataFilter.some((array) =>
      array.includes(name)
    );
    let checkSubIndustryArr = subindustryDataFilter.some((array) =>
      array.includes(name)
    );

    if (checkCountryArr)
      dispatch(
        countryFilterSelected(countryData.filter((e) => e.label !== name))
      );

    if (checkIndustryArr)
      dispatch(
        industryFilterSelected(industryDataFilter.filter((e) => e !== name))
      );

    if (checkSubIndustryArr)
      dispatch(
        subindustryFilterSelected(
          subindustryDataFilter.filter((e) => e !== name)
        )
      );

    dispatch(activityFilterSelected(activityDataFilter.filter((e)=>e!==name)))
    dispatch(companySizeFilterSelected(companySizeDataFilter.filter((e)=>e!==name)))
    dispatch(departmentFilterSelected(departmentDataFilter.filter((e)=>e!==name)))
    dispatch(seniorityFilterSelected(seniorityDataFilter.filter((e)=>e!==name)))
    dispatch(domainselected(domain.filter((e)=>e!==name)))
    dispatch(applyfilterSelected(true))
  };
  return (
    <div className="wrapper_filters">
      <div className="filter_outer">
        {(allFilter || []).map((e) => {
          return (
            <div className="remoove" key={e} onClick={() => removeFilter(e)}>
              <span>{e}</span>
              <i className="fa-solid fa-xmark"></i>
            </div>
          );
        })}
      </div>

      <div className="button_options">
        <div className="remoove">
          <a href="#">Show More</a>
        </div>
        <div className="remoove">
          <a href="#" onClick={() => dispatch(resetAll())}>
            Clear All
          </a>
        </div>
      </div>
    </div>
  );
}
