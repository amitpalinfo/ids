import React, { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import _ from "lodash";
import Select from "react-select";
import MultipleValueTextInput from "react-multivalue-text-input";

import {
  countryFilterSelected,
  industryFilterSelected,
  subindustryFilterSelected,
  activityFilterSelected,
  companySizeFilterSelected,
  departmentFilterSelected,
  seniorityFilterSelected,
  applyfilterSelected,
  domainselected,
  stdselected,
  filterApplySelected,
} from "../store/slices/companySlices";

export default function Sidebar() {
  const dispatch = useDispatch();
  const [countryFilter, setCountryFilter] = useState([]);
  const [industryFilter, setIndustryFilter] = useState([]);
  const [industryFilterDropdown, setIndustryFilterDropdown] = useState([]);
  const [subIndustryFilter, setSubIndustryFilter] = useState([]);
  const [subIndustryFilterDropdown, setSubIndustryFilterDropdown] = useState(
    []
  );
  const [departmentFilter, setDepartmentFilter] = useState([]);
  const [departmentFilterDropdown, setDepartmentFilterDropdown] = useState([]);
  const [activityFilter, setActivityFilter] = useState([]);
  const [activityFilterDropdown, setActivityFilterDropdown] = useState([]);
  const [companySizeFilter, setcompanySizeFilter] = useState([]);
  const [companySizeFilterDropdown, setcompanySizeFilterDropdown] = useState(
    []
  );
  const [senorityFilter, setSenorityFilter] = useState([]);
  const [senorityFilterDropdown, setSenorityFilterDropdown] = useState([]);
  const [domainfilter, setDomainFilter] = useState([]);
  const [locations, setLocation] = useState([]);
  const [stdChecked, setStdChecked] = useState(false);
  const [dropdown, setDropDown] = useState({
    Industry: false,
    sub_industry: null,
  });

  const [selectedOptions, setSelectedOptions] = useState([]);
  const [options, setOptions] = useState([]);

  const {
    countryData,
    industryDataFilter,
    subindustryDataFilter,
    activityDataFilter,
    companySizeDataFilter,
    departmentDataFilter,
    seniorityDataFilter,
    domain,
    std,
    apiData,
    loader,
  } = useSelector((state) => state.denave);

  useEffect(() => {
    setIndustryFilter(industryDataFilter);
    setSubIndustryFilter(subindustryDataFilter);
    setDepartmentFilter(departmentDataFilter);
    setActivityFilter(activityDataFilter);
    setcompanySizeFilter(companySizeDataFilter);
    setSenorityFilter(seniorityDataFilter);
    setSelectedOptions(countryData);
  }, [
    countryData,
    industryDataFilter,
    subindustryDataFilter,
    activityDataFilter,
    companySizeDataFilter,
    departmentDataFilter,
    seniorityDataFilter,
  ]);

  //Industry Filter
  const handleSelectChange = (selectedIndustry, type) => {
    if (type === "industry")
      setIndustryFilter(selectedIndustry.map((e) => e.value));
    if (type === "subindustry")
      setSubIndustryFilter(selectedIndustry.map((e) => e.value));
    if (type === "country")
      setCountryFilter(selectedIndustry.map((e) => e.value));

    if (type === "department")
      setDepartmentFilter(selectedIndustry.map((e) => e.value));

    if (type === "activity")
      setActivityFilter(selectedIndustry.map((e) => e.value));

    if (type === "company_size")
      setcompanySizeFilter(selectedIndustry.map((e) => e.value));

    if (type === "senority")
      setSenorityFilter(selectedIndustry.map((e) => e.value));
  };

  useEffect(() => {
    dispatch(countryFilterSelected(selectedOptions));
    dispatch(industryFilterSelected(industryFilter));
    dispatch(subindustryFilterSelected(subIndustryFilter));
    dispatch(activityFilterSelected(activityFilter));
    dispatch(companySizeFilterSelected(companySizeFilter));
    dispatch(departmentFilterSelected(departmentFilter));
    dispatch(seniorityFilterSelected(senorityFilter));
    dispatch(domainselected(domainfilter));
    dispatch(stdselected(stdChecked));
  }, [
    dispatch,
    selectedOptions,
    industryFilter,
    subIndustryFilter,
    activityFilter,
    companySizeFilter,
    departmentFilter,
    senorityFilter,
    domainfilter,
    stdChecked,
  ]);

  useEffect(() => {
    if (subindustryDataFilter.length) {
      let Industry = _.groupBy(
        apiData.vertical.filter((e) =>
          subindustryDataFilter.length
            ? subindustryDataFilter.includes(e.SUB_VERTICAL)
            : e
        ),
        "VERTICAL"
      );
      const filteredDataIndustrssy = Object.keys(Industry);
      filteredDataIndustrssy.forEach((e) => {
        if (!industryFilter.includes(e)) {
          setIndustryFilter((prev) => [...prev, e]);
        }
      });
    }
  }, [subindustryDataFilter, apiData, industryFilter]);

  // industryDataFilter

  useEffect(() => {
    // Industry Dropdown

    let Industry = _.groupBy(apiData.vertical, "VERTICAL");
    // setIndustryFilter()
    const filteredDataIndustry = Object.keys(Industry)
      .filter((e) => e)
      .map((d) => {
        return { value: d, label: d };
      });

    setIndustryFilterDropdown(filteredDataIndustry);

    // Sub Industry Dropdown
    const subInd = (apiData.vertical || [])
      .filter((f) =>
        industryDataFilter.length
          ? industryDataFilter.includes(f.VERTICAL)
          : f.VERTICAL
      )
      .filter(
        (obj, index, self) =>
          index === self.findIndex((t) => t.SUB_VERTICAL === obj.SUB_VERTICAL)
      );

    const filteredDataSubIndustry = subInd
      .filter((e) => e.SUB_VERTICAL)
      .map((d) => {
        return { value: d.SUB_VERTICAL, label: d.SUB_VERTICAL };
      });

    setSubIndustryFilterDropdown(filteredDataSubIndustry);

    // Activity Type
    let activityType = _.groupBy(apiData.vertical, "ACTIVITY_TYPE");
    const filteredDataActivity = Object.keys(activityType)
      .filter((e) => e)
      .map((d) => {
        return { value: d, label: d };
      });

    setActivityFilterDropdown(filteredDataActivity);

    // Company Size
    let CompanySize = (apiData.company_size || []).map((d) => {
      return { value: d.LKP_VALUES, label: d.LKP_VALUES };
    });

    setcompanySizeFilterDropdown(CompanySize);

    // Department
    let department = _.groupBy(apiData.department, "DEPARTMENT");
    const filteredDataDepartment = Object.keys(department)
      .filter((e) => e)
      .map((d) => {
        return { value: d, label: d };
      });
    setDepartmentFilterDropdown(filteredDataDepartment);

    // Job or Seniority

    let senorityLevel = _.groupBy(apiData.department, "JOB_LEVEL");
    const filteredDataSenority = Object.keys(senorityLevel)
      .filter((e) => e)
      .map((d) => {
        return { value: d, label: d };
      });

    setSenorityFilterDropdown(filteredDataSenority);

    // Country

    const locationsList = (apiData.country_data || []).map((e) => {
      return {
        COUNTRY: e.COUNTRY,
        STATE: e.STATE,
        CITY: e.CITY,
      };
    });

    setLocation(locationsList);
  }, [apiData, industryDataFilter]);

  // Country FIlter Function

  const generateOptions = (searchText) => {
    const filteredLocations = locations.filter(
      (loc) =>
        loc.COUNTRY.toLowerCase().startsWith(searchText.toLowerCase()) ||
        loc.STATE.toLowerCase().startsWith(searchText.toLowerCase()) ||
        loc.CITY.toLowerCase().startsWith(searchText.toLowerCase())
    );

    let COUNTRY = locations.filter((loc) =>
      loc.COUNTRY.toLowerCase().startsWith(searchText.toLowerCase())
    );

    let STATE = locations.filter((loc) =>
      loc.STATE.toLowerCase().startsWith(searchText.toLowerCase())
    );

    let CITY = locations.filter((loc) =>
      loc.CITY.toLowerCase().startsWith(searchText.toLowerCase())
    );

    const searchLabel = filteredLocations
      .map((loc) => ({
        value: COUNTRY.length
          ? { COUNTRY: loc.COUNTRY }
          : STATE.length
          ? { STATE: loc.STATE, COUNTRY: loc.COUNTRY }
          : CITY.length
          ? { CITY: loc.CITY, STATE: loc.STATE, COUNTRY: loc.COUNTRY }
          : "",

        label: COUNTRY.length
          ? loc.COUNTRY.toUpperCase()
          : STATE.length
          ? loc.STATE.toUpperCase() + "," + loc.COUNTRY.toUpperCase()
          : CITY.length
          ? loc.CITY.toUpperCase() +
            "," +
            loc.STATE.toUpperCase() +
            "," +
            loc.COUNTRY.toUpperCase()
          : "",
      }))

      .filter(
        (obj, index, self) =>
          index === self.findIndex((t) => t.label === obj.label)
      );
    // .filter(
    //   (obj, index, self) =>
    //     index === self.findIndex((t) => t.STATE === obj.STATE)
    // );

    return searchLabel;
  };

  const customStyles = {
    // control: (provided, state) => ({
    //   ...provided,
    //   width: '300px', // set the width of the control element
    // }),
    menu: (provided, state) => ({
      ...provided,
      width: "350px", // set the width of the suggestion div
    }),
  };

  const handleCheckboxChange = (event) => {
    setStdChecked(event.target.checked);
  };

  // console.log("industryFilter",filteredDataIndustry)
  // setDomainFilter([...domainfilter, value]);

  const handleOnChange = (newValues) => {
    setDomainFilter([...domainfilter, newValues.target.value]);

    console.log("newValues", newValues);
  };

  const handleRemoveValue = (valueToRemove) => {
    const newValues = domainfilter.filter((value) => value !== valueToRemove);
    setDomainFilter(newValues);
    console.log("valueToRemove", valueToRemove);
  };

  return (
    <div className="sidebar text-justify	">
      <div className="logo">
        <img src={"./logo.png"} alt="" />
      </div>

      <div className="nav_menu">
        {/* <div className="row">
          <div className="column-1">
            <p>Date</p>
          </div>
          <div className="column-2">
            <div className="option">
              <input type="radio" id="html" name="fav_language" value="HTML" />
              <label for="html">Created Date</label>
            </div>
            <div className="option">
              <input type="radio" id="html" name="fav_language" value="HTML" />
              <label for="html">Modified Date</label>
            </div>
            <div className="date_input">
              <input type="date" id="DAte" />
            </div>
          </div>
        </div> */}

        <div className="Nav_part">
          <div className="nav_heading">
            <p>Company</p>
          </div>
          <div className="nav_list">
            {/* Region */}
            {/* <button
              className={`dropdown-btn mt-3 ${
                dropdown.region ? "active" : ""
              } `}
              onClick={() =>
                setDropDown((dropdown) => {
                  return {
                    ...dropdown,
                    region: !dropdown.region,
                  };
                })
              }
            >
              <i className="fa-solid fa-chevron-right"></i>Region
              <span className="text-sm" style={{ color: "red" }}>
                {" "}
                *
              </span>
            </button>
            {dropdown.region && (
              <div className="dropdown-container">
                {/* <Select
                  closeMenuOnSelect={true}
                  value={selectedOptions}
                  options={options}
                  onInputChange={(value) => setOptions(generateOptions(value))}
                  onChange={(options) => setSelectedOptions(options)}
                  placeholder="Search region"
                  isMulti
                /> 
              </div>
            )} */}

            {/* Country */}
            <button
              className={`dropdown-btn mt-3 mb-3 ${
                dropdown.country ? "active" : ""
              } `}
              onClick={() =>
                setDropDown((dropdown) => {
                  return {
                    ...dropdown,
                    country: !dropdown.country,
                  };
                })
              }
            >
              <i className="fa-solid fa-chevron-right"></i>Country, State, City
              <span className="text-sm" style={{ color: "red" }}>
                {" "}
                *
              </span>
            </button>
            {dropdown.country && (
              <div className="dropdown-container">
                <Select
                  closeMenuOnSelect={true}
                  value={selectedOptions}
                  options={options}
                  onInputChange={(value) => setOptions(generateOptions(value))}
                  onChange={(options) => setSelectedOptions(options)}
                  placeholder="Search country, state , city"
                  isMulti
                  styles={customStyles}
                />
              </div>
            )}

            {/* Industry */}
            <button
              className={`dropdown-btn ${dropdown.Industry ? "active" : ""} `}
              onClick={() =>
                setDropDown((dropdown) => {
                  return {
                    ...dropdown,
                    Industry: !dropdown.Industry,
                  };
                })
              }
            >
              <i className="fa-solid fa-chevron-right"></i>Industry
            </button>

            {dropdown.Industry && (
              <div className="dropdown-container">
                <Select
                  closeMenuOnSelect={false}
                  value={industryFilterDropdown?.filter((f) =>
                    industryDataFilter.includes(f.value)
                  )}
                  isMulti
                  options={industryFilterDropdown}
                  onChange={(e) => handleSelectChange(e, "industry")}
                  placeholder="Search Industry"
                  styles={customStyles}
                />
              </div>
            )}
            {/* SubIndustry */}
            <button
              className={`dropdown-btn mt-3 ${
                dropdown.sub_industry ? "active" : ""
              } `}
              onClick={() =>
                setDropDown((dropdown) => {
                  return {
                    ...dropdown,
                    sub_industry: !dropdown.sub_industry,
                  };
                })
              }
            >
              <i className="fa-solid fa-chevron-right"></i>Sub Industry
            </button>
            {dropdown.sub_industry && (
              <div className="dropdown-container">
                <Select
                  closeMenuOnSelect={false}
                  value={subIndustryFilterDropdown?.filter((f) =>
                    subindustryDataFilter.includes(f.value)
                  )}
                  onChange={(e) => handleSelectChange(e, "subindustry")}
                  isMulti
                  options={subIndustryFilterDropdown}
                  placeholder="Search sub-Industry"
                  styles={customStyles}
                />
              </div>
            )}

            {/* Activity Type */}
            <button
              className={`dropdown-btn mt-3 ${
                dropdown.activityType ? "active" : ""
              } `}
              onClick={() =>
                setDropDown((dropdown) => {
                  return {
                    ...dropdown,
                    activityType: !dropdown.activityType,
                  };
                })
              }
            >
              <i className="fa-solid fa-chevron-right"></i>Activity Type
            </button>
            {dropdown.activityType && (
              <div className="dropdown-container">
                <Select
                  closeMenuOnSelect={false}
                  value={activityFilterDropdown?.filter((f) =>
                    activityDataFilter.includes(f.value)
                  )}
                  onChange={(e) => handleSelectChange(e, "activity")}
                  isMulti
                  options={activityFilterDropdown}
                  placeholder="Search Activity"
                  styles={customStyles}
                />
              </div>
            )}

            {/* Company Size */}
            <button
              className={`dropdown-btn mt-3 ${
                dropdown.companySize ? "active" : ""
              } `}
              onClick={() =>
                setDropDown((dropdown) => {
                  return {
                    ...dropdown,
                    companySize: !dropdown.companySize,
                  };
                })
              }
            >
              <i className="fa-solid fa-chevron-right"></i>Company Size
            </button>
            {dropdown.companySize && (
              <div className="dropdown-container">
                <Select
                  closeMenuOnSelect={false}
                  value={companySizeFilterDropdown?.filter((f) =>
                    companySizeDataFilter.includes(f.value)
                  )}
                  isMulti
                  options={companySizeFilterDropdown}
                  onChange={(e) => handleSelectChange(e, "company_size")}
                  placeholder="Company Size"
                  styles={customStyles}
                />
              </div>
            )}

            {/* Domain Name */}
            <button
              className={`dropdown-btn mt-3 ${
                dropdown.domainName ? "active" : ""
              } `}
              onClick={() =>
                setDropDown({
                  domainName: !dropdown.domainName,
                })
              }
            >
              <i className="fa-solid fa-chevron-right"></i>Domain Name
            </button>
            {dropdown.domainName && (
              <div className="dropdown-container">
                <MultipleValueTextInput
                  // value={domainfilter}
                  // onChange={handleOnChange}
                  // onRemove={handleRemoveValue}
                  // onItemDeleted={(index) => {
                  //   const newValues = [...domainfilter];
                  //   newValues.splice(index, 1);
                  //   setDomainFilter(newValues);
                  // }}
                  onItemAdded={(item, allItems) =>
                    setDomainFilter([...domainfilter, item])
                  }
                  onItemDeleted={(item, allItems) =>
                    setDomainFilter([allItems])
                  }
                  label=""
                  name="item-input"
                  placeholder="Enter Domain name"
                />
              </div>
            )}
          </div>
        </div>

        <div className="Nav_part">
          <div className="nav_heading">
            <p>Contact</p>
          </div>
          <div className="nav_list">
            {/* Department */}
            <button
              className={`dropdown-btn mt-3 ${
                dropdown.department ? "active" : ""
              } `}
              onClick={() =>
                setDropDown((dropdown) => {
                  return {
                    ...dropdown,
                    department: !dropdown.department,
                  };
                })
              }
            >
              <i className="fa-solid fa-chevron-right"></i>Department
            </button>

            {dropdown.department && (
              <div className="dropdown-container">
                <Select
                  closeMenuOnSelect={false}
                  value={departmentFilterDropdown?.filter((f) =>
                    departmentDataFilter.includes(f.value)
                  )}
                  isMulti
                  options={departmentFilterDropdown}
                  onChange={(e) => handleSelectChange(e, "department")}
                  placeholder="Search Department"
                  styles={customStyles}
                />
              </div>
            )}

            {/* Job Title */}

            <button
              className={`dropdown-btn mt-3 ${
                dropdown.senority ? "active" : ""
              } `}
              onClick={() =>
                setDropDown((dropdown) => {
                  return {
                    ...dropdown,
                    senority: !dropdown.senority,
                  };
                })
              }
            >
              <i className="fa-solid fa-chevron-right"></i>Seniority Level
            </button>

            {dropdown.senority && (
              <div className="dropdown-container">
                <Select
                  closeMenuOnSelect={false}
                  value={senorityFilterDropdown?.filter((f) =>
                    seniorityDataFilter.includes(f.value)
                  )}
                  isMulti
                  options={senorityFilterDropdown}
                  onChange={(e) => handleSelectChange(e, "senority")}
                  placeholder="Search Senority Level"
                  styles={customStyles}
                />
              </div>
            )}
          </div>
        </div>

        {/* <div className="Nav_part">
          <div className="nav_heading">
            <p>Company Category</p>
          </div>
          <div className="nav_list">
            <ul className="navigation_list">
              <li className="item">
                <a href="#" className="link">
                  <i className="fa-solid fa-chevron-right"></i>Category
                </a>
              </li>
              <li className="item">
                <a href="#" className="link">
                  <i className="fa-solid fa-chevron-right"></i>Sub-Category
                </a>
              </li>
            </ul>
          </div>
        </div> */}

        <div className="Nav_part">
          <div className="nav_heading">
            <p>Profiling Status</p>
          </div>
          <div className="check_list">
            <div className="check">
              <input
                type="checkbox"
                id="std"
                name="std"
                value="1"
                // value="Bike"
                onChange={handleCheckboxChange}
              />
              <label for="vehicle1"> STD</label>
            </div>
            {/* <div className="check">
              <input
                type="checkbox"
                id="vehicle1"
                name="vehicle1"
                value="Bike"
              />
              <label for="vehicle1"> Email</label>
            </div>
            <div className="check">
              <input
                type="checkbox"
                id="vehicle1"
                name="vehicle1"
                value="Bike"
              />
              <label for="vehicle1"> Mobile</label>
            </div> */}
          </div>
        </div>

        <div className="button_save">
          <button
            type="button"
            onClick={() => {
              if (loader) {
              } else {
                dispatch(applyfilterSelected(true));
                dispatch(filterApplySelected(true));
              }
            }}
          >
            {loader ? "Please wait.." : "Apply Filter"}
          </button>
        </div>
      </div>
    </div>
  );
}
