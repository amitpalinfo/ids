import React, { useState } from "react";

export default function TopBar() {
  const storedData = JSON.parse(localStorage.getItem("user"));
  console.log("storedData", storedData);
  const [isOpen, setIsOpen] = useState(false);

  function handleButtonClick() {
    setIsOpen(!isOpen);
  }

  function handleLogoutClick() {
    localStorage.removeItem("user");
    window.location.href = "/";
  }

  return (
    <div className="top">
      <div className="tab">
        <div className="top_button">
          {/* <div className="logo">
        <img src={"./logo.png"} alt="" />
      </div> */}
          {/* <button type="submit">Dashboard</button> */}
        </div>
        {/* <div className="top_button"><button type="submit">Companies</button></div>
                    <div className="top_button"><button type="submit">Insights</button></div>
                    <div className="top_button"><button type="submit">Saved Searches</button></div> */}
      </div>
      <div className="outer_right">
        <div className="search_bar_wrap">
          <div className="icon">
            <i className="fa-solid fa-magnifying-glass"></i>
          </div>
          <div className="search">
            <input disabled="true" type="text" placeholder="Search.." />
          </div>
        </div>

        <div className="profile profile-dropdown">
          <button
            className="profile-dropdown__button"
            onClick={handleButtonClick}
          >
            <img
              className="profile-dropdown__avatar"
              src={"./denaveavtartlogo.png"}
              alt={""}
            />
          </button>
          {isOpen && (
            <ul className="profile-dropdown__options">
              <li className="profile-dropdown__option">
                {storedData.username}
              </li>
              <li
                className="profile-dropdown__option"
                onClick={handleLogoutClick}
              >
                Logout
              </li>
              {/* Add more options as needed */}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
