import React from 'react'
import Sidebar from '../Sidebar'
import Main from '../Main'

export default function Landing() {
  return (
    <div className="section">
        <Sidebar />
<Main /> 
</div>
  )
}
