import React, { useMemo } from "react";
import { useSelector, useDispatch } from "react-redux";
import { allApiData } from "../store/slices/companySlices";

import TopBar from "./TopBar";
import WrapperFilter from "./WrapperFilter";
import Overview from "./Overview";
import Blocks from "./Blocks";
import Search from "./Search";
import { API_URL } from "../service/Const";
import Loader from "./Loader";

export default function Main() {
  const dispatch = useDispatch();
  const { countryData, loader, applyfilter,filterApply } = useSelector((state) => state.denave);

  useMemo(() => {
    fetch(`${API_URL}/get_data`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => dispatch(allApiData(data)))
      .catch((error) => {
        console.error(error);
      });
  }, [dispatch]);

  if (countryData.length && filterApply)
    return (
      <div className="dashboard-section">
        <TopBar />
        
            <WrapperFilter />
            <Overview />
            <Blocks />
         
     
      </div>
    );
  else
    return (
      <div className="dashboard-section">
        <TopBar />
        <Search />
      </div>
    );
}
