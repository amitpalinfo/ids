import React, { useState } from "react";
import axios from "axios";
import { API_URL } from "../service/Const";
import { useDispatch } from "react-redux";
import { userdataGet } from "../store/slices/companySlices";



function Login() {
  const dispatch = useDispatch();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState("");


  // handle login form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post(`${API_URL}/login`, { email, password })
      .then(response => {
        console.log("response", response)
        if (response.data.status) {
          // Store data in local storage
          dispatch(userdataGet(response.data.user))
          localStorage.setItem('user', JSON.stringify(response.data.user));

          window.location.href = '/';

        } else {
          setError(response.data.msg);
        }
      })
      .catch(error => {
        setError(error.response.data.msg);
      });
  };

  return (
    //   <div class="login-box">

    // 	<h2>Login</h2>
    //   {error}
    // 	<form onSubmit={handleSubmit}>
    // 		<label>Email</label>
    // 		<input type="email" name="email" placeholder="Enter Email" onChange={(e) => setEmail(e.target.value)} />
    // 		<label>Password</label>
    // 		<input type="password" name="password" placeholder="Enter Password" onChange={(e) => setPassword(e.target.value)} />
    // 		<input type="submit" value="Login" />

    // 	</form>
    // </div>

    <section className="login">
      <div className="outer">
        <div className="login_form">
          <div className="container">

            <div className="modal">
              <div className="logo">
                <img src="./logo.png" alt="" />
              </div>

              <div className="heading_main">
                <h1 className="big">Welcome</h1>
                {/* <p className="small">Lorem Ipsum is simply dummy text</p> */}
              </div>

              <form className="login_fields" onSubmit={handleSubmit}>
                <label for="email">Email</label>
                <input type="text" placeholder="Enter Email" name="email"
                  onChange={(e) => setEmail(e.target.value)}

                  required />

                <label for="psw">Password</label>
                <div className="password-container">
                  <input type="password" placeholder="Password..." id="password"
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <i className="fa-regular fa-eye"></i>
                </div>

                <div className="check_box">
                  <label> <input type="checkbox" checked="checked" name="remember" /> I agree with terms &
                    conditions </label>
                </div>

                <div className="bottom">
                  <div className="button">
                    <button type="submit">Login <span><img src="./arrow.svg"
                      alt="" /></span></button>
                  </div>
                  <a href="#">Forgot Password?</a>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div class="right_img">
          <img src="./Login_form_img.jpg" alt="" />
        </div>

      </div>
    </section>
  );
}

export default Login;
