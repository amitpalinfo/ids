import React, { useEffect, useState, useCallback } from "react";
import { useSelector } from "react-redux";

import Modal from "./Modal";
import { API_URL } from "../service/Const";
import axios from "axios";

export default function Overview() {
  const [account, setAccount] = useState(0);
  const [email, setEmail] = useState(0);
  const [mobile, setMobile] = useState(0);
  const [linkedinId, setLinkedinId] = useState(0);
  const [contact, setContact] = useState(0);
  const [loading, setLoading] = useState(false);

  const {
    countryData,
    industryDataFilter,
    subindustryDataFilter,
    activityDataFilter,
    companySizeDataFilter,
    departmentDataFilter,
    seniorityDataFilter,
    overviewData,
    domain,
    std,
  } = useSelector((state) => state.denave);

  const chartFunCount = useCallback(async () => {
    overviewData?.forEach((e) => {
      setAccount(e.ORG_COUNT);
      setEmail(e.EMAIL_ID_COUNT);
      setMobile(e.MOBILE_COUNT);
      setLinkedinId(e.LINKEDIN_URL_COUNT);
      setContact(e.CONTACT_COUNT);
    });
  }, [overviewData]);

  useEffect(() => {
    chartFunCount();
  }, [chartFunCount, overviewData]);

  const [modalIsOpen, setModalIsOpen] = useState(false);

  const closeModal = () => {
    setModalIsOpen(!modalIsOpen);
    setSuccessMsg({
      status: false,
      msg: null,
    });
  };
  const [formState, setFormState] = useState({
    client_name: "",
    project_name: "",
    product_name: "",
    purpose: "",
  });

  const [successMsg, setSuccessMsg] = useState({
    status: false,
    msg: null,
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormState({ ...formState, [name]: value });
  };

  // Get Country Array
  const countryArray = countryData
    .filter((aar) => aar.value.COUNTRY)
    .map((c) => c.value)
    .filter(
      (obj, index, self) =>
        index === self.findIndex((t) => t.COUNTRY === obj.COUNTRY) &&
        obj.COUNTRY
    )
    .map((r) => r.COUNTRY);

  // Get State Array
  const stateArray = countryData
    .filter((aar) => aar.value.STATE)
    .map((c) => c.value)
    .filter(
      (obj, index, self) =>
        index === self.findIndex((t) => t.STATE === obj.STATE) && obj.STATE
    )
    .map((r) => r.STATE);

  // Get City Array
  const cityArray = countryData
    .filter((aar) => aar.value.CITY)
    .map((c) => c.value)
    .filter(
      (obj, index, self) =>
        index === self.findIndex((t) => t.CITY === obj.CITY) && obj.CITY
    )
    .map((r) => r.CITY);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);

    const storedData = JSON.parse(localStorage.getItem("user"));
    console.log("storedData", storedData);

    const postData = {
      email: storedData?.email,
      filters: {
        VERTICAL: industryDataFilter,
        SUB_VERTICAL: subindustryDataFilter,
        COUNTRY: countryArray,
        STATE: stateArray,
        CITY: cityArray,
        ACTIVITY_TYPE: activityDataFilter,
        TOTAL_EMPLOYEE_COUNT: companySizeDataFilter,
        DOMAIN_NAME: domain,
        JOB_LEVEL: seniorityDataFilter,
        DEPARTMENT: departmentDataFilter,
        STD: std,
        EMAIL: "1",
        MOBILE: "",
      },
      form_data: formState,
    };

    const config = {
      headers: {
        "Content-Type": "application/json",
      },
    };

    // GET REPORT DATA STATUS
    await axios
      .post(`${API_URL}/report-data`, JSON.stringify(postData), config)
      .then((response) => {
        console.log(response);
        if (response.data.success) {
          setSuccessMsg({
            status: true,
            msg: response.data.msg,
          });
          setLoading(false);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <div className="overview">
      <Modal isOpen={modalIsOpen} onClose={closeModal}>
        {!successMsg.status ? (
          <form className="grid-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label for="name">
                Client Name<span style={{ color: "red" }}>*</span>
              </label>
              <input
                type="text"
                value={formState.CLIENT_NAME}
                name={"CLIENT_NAME"}
                placeholder="Enter Client Name"
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label for="email">
                Product Name<span style={{ color: "red" }}>*</span>
              </label>
              <input
                type="text"
                value={formState.PRODUCT_NAME}
                name={"PRODUCT_NAME"}
                placeholder="Enter Product Name"
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label for="email">
                Project Name<span style={{ color: "red" }}>*</span>
              </label>
              <input
                type="text"
                value={formState.PROJECT_NAME}
                name={"PROJECT_NAME"}
                placeholder="Enter Project Name"
                onChange={handleInputChange}
                required
              />
            </div>

            <div className="form-group">
              <label for="Purpose">
                PURPOSE<span style={{ color: "red" }}>*</span>
              </label>
              <select
                id="Purpose"
                name="PURPOSE"
                className=""
                onChange={handleInputChange}
                required
              >
                <option value="">Select an option</option>
                <option value="Telecalling">Telecalling</option>
                <option value="Digital Marketing">Digital Marketing</option>
                <option value="Social Media Campaign">
                  Social Media Campaign
                </option>
                <option value="Lead Generation">Lead Generation</option>
                <option value="Email Marketing Campaign">
                  Email Marketing Campaign
                </option>
                <option value="Others">Others</option>
              </select>
            </div>

            <div className="form-group">
              <label for="TYPE_OF_DOWNLOAD">
                Type Of Download<span style={{ color: "red" }}>*</span>
              </label>
              <select
                name="TYPE_OF_DOWNLOAD"
                id="TYPE_OF_DOWNLOAD"
                className=""
                onChange={handleInputChange}
                required
              >
                <option value="">Select an option</option>
                <option value="Prospecting">Prospecting</option>
                <option value="Delivery">Delivery</option>
              </select>
            </div>

            <button type="submit">
              {loading ? "Please wait..." : "Get Data"}
            </button>
          </form>
        ) : (
          <p>{successMsg.msg}</p>
        )}
      </Modal>
      <div className="outter">
        <div className="heading">
          <h1>Overview</h1>
        </div>

        <div className="overview_detail_main">
          <div className="parts">
            <div className="part">
              <div className="up">
                <p> Accounts</p>
              </div>
              <div className="down">
                <p> {account}</p>
              </div>
            </div>
            <div className="part">
              <div className="up">
                <p> Contacts</p>
              </div>
              <div className="down">
                <p> {contact}</p>
              </div>
            </div>
            <div className="part">
              <div className="up">
                <p> LinkedIn</p>
              </div>
              <div className="down">
                <p> {linkedinId}</p>
              </div>
            </div>
            <div className="part">
              <div className="up">
                <p> Email</p>
              </div>
              <div className="down">
                <p> {email}</p>
              </div>
            </div>
            <div className="part">
              <div className="up">
                <p> Mobile</p>
              </div>
              <div className="down">
                <p> {mobile}</p>
              </div>
            </div>
          </div>
          <div className="button_save">
            <button type="button" onClick={() => setModalIsOpen(!modalIsOpen)}>
              Get Data
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
