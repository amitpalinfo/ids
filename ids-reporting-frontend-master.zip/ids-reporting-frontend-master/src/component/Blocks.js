import React, { useEffect, useState, useCallback } from "react";
import Plot from "react-plotly.js";
import { useSelector, useDispatch } from "react-redux";

import { FilterData } from "../service/FilterData";
import { SubFilterDataRequest } from "../service/SubFilterDataRequest";
import {
  overviewFilterSelected,
  applyfilterSelected,
  loaderselected
} from "../store/slices/companySlices";
import Loader from './Loader'

export default function Blocks() {
  const dispatch = useDispatch();

  const {
    countryData,
    industryDataFilter,
    subindustryDataFilter,
    activityDataFilter,
    companySizeDataFilter,
    departmentDataFilter,
    seniorityDataFilter,
    domain,
    std,
    applyfilter,
    loader
  } = useSelector((state) => state.denave);

  const [industryData, setIndustryData] = useState([]);
  const [companySize, setCompanySize] = useState([]);
  const [departmentData, setdepartmentData] = useState([]);
  const [seniorityData, setSeniorityDataData] = useState([]);
  const [subIndustryData, setSubIndustryData] = useState([]);
  const [activityTypeData, setActivityTypeData] = useState([]);
  const [isLoading,setIsLoading]=useState(false)

  


  const chartFun = useCallback(async () => {

    if(applyfilter){

    const filterData = await FilterData(
      countryData,
      industryDataFilter,
      subindustryDataFilter,
      activityDataFilter,
      companySizeDataFilter,
      departmentDataFilter,
      seniorityDataFilter,
      domain,
      std
    );
    dispatch(applyfilterSelected(false))
    dispatch(loaderselected(false))

    // overviewcard

    dispatch(overviewFilterSelected(filterData.overview?.map((e) => e)));

    // Industry Chart

    const indus = filterData.vertical_count
      ?.map((e) => {
        return { VERTICAL: e.VERTICAL, ORG_COUNT: e.ORG_COUNT };
      })
      .filter((ee) => ee.VERTICAL !== "");

    const company = indus?.map((e) => e.VERTICAL);

    const companyIndustry = indus.map((e) => e.ORG_COUNT);

    // const industryHoverLabel =
    //   Industry &&
    //   Object.keys(Industry).map(function (key) {
    //     const oo = Industry[key]
    //       .filter((e) => e.Country)
    //       .reduce((prev, curr) => {
    //         prev[curr.Country] = (prev[curr.Country] || 0) + 1;
    //         return prev;
    //       }, {});

    //     return oo;
    //   });

    const data = [
      {
        values: companyIndustry,
        labels: company,
        hole: 0.4,
        type: "pie",
        textinfo: "value",
        textposition: "inside",
        marker: { size: 10 },
        
        sort: false,


        // text: Object.values(industryHoverLabel).map((h) =>
        //   JSON.stringify(h)
        //     .replace(/[,]/g, "<br>")
        //     .replace(/[{}]/g, "")
        //     .replace(/["]/g, "")
        // ),
        hovertemplate: "<b>%{label}</b><extra></extra>",
      },
    ];

    setIndustryData(data);

    // Company Size Chart

    const size = filterData.compant_count
      ?.map((e) => {
        return {
          TOTAL_EMPLOYEE_COUNT: e.TOTAL_EMPLOYEE_COUNT,
          ORG_COUNT: e.ORG_COUNT,
        };
      })
      .filter((ee) => ee.TOTAL_EMPLOYEE_COUNT !== "");

    console.log(size);
    const CompanySizeLabel = size?.map((e) => e.TOTAL_EMPLOYEE_COUNT);
    console.log(CompanySizeLabel, "Company Size");
    const CompanySizeCountry = size?.map((e) => e.ORG_COUNT);

    // const companyHoverLabel =
    //   CompanySize &&
    //   Object.keys(CompanySize).map(function (key) {
    //     const oo = CompanySize[key]
    //       .filter((e) => e.Country)
    //       .reduce((prev, curr) => {
    //         prev[curr.Country] = (prev[curr.Country] || 0) + 1;
    //         return prev;
    //       }, {});

    //     return oo;
    //   });

    const CompanySizeData = [
      {
        values: CompanySizeCountry,
        labels: CompanySizeLabel,
        hole: 0.4,
        type: "pie",
        textinfo: "value",
        textposition: "inside",
        sort: false,
        // text: Object.values(companyHoverLabel).map((h) =>
        //   JSON.stringify(h)
        //     .replace(/[,]/g, "<br>")
        //     .replace(/[{}]/g, "")
        //     .replace(/["]/g, "")
        // ),
        hovertemplate: "<b>%{label}</b><extra></extra>",
      },
    ];

    setCompanySize(CompanySizeData);

    // Department chart

    const department = filterData.department_count
      ?.map((e) => {
        return { DEPARTMENT: e.DEPARTMENT, ORG_COUNT: e.ORG_COUNT };
      })
      .filter((ee) => ee.DEPARTMENT !== "");

    const departmentDataLabel = department?.map((e) => e.DEPARTMENT);

    const departmentDataLabelCountry = department
      ?.map((e) => e.ORG_COUNT)
      .filter((ee) => ee !== "");

    // const departmentHoverLabel =
    //   departmentData &&
    //   Object.keys(departmentData).map(function (key) {
    //     const oo = departmentData[key]
    //       .filter((e) => e.Country)
    //       .reduce((prev, curr) => {
    //         prev[curr.Country] = (prev[curr.Country] || 0) + 1;
    //         return prev;
    //       }, {});

    //     return oo;
    //   });

    const departmentDataLabelCountryData = [
      {
        values: departmentDataLabelCountry,
        labels: departmentDataLabel,
        hole: 0.4,
        type: "pie",
        textinfo: "value",
        textposition: "inside",
        sort: false,
        // text: Object.values(departmentHoverLabel).map((h) =>
        //   JSON.stringify(h)
        //     .replace(/[,]/g, "<br>")
        //     .replace(/[{}]/g, "")
        //     .replace(/["]/g, "")
        // ),
        hovertemplate: "<b>%{label}</b><extra></extra>",
      },
    ];

    setdepartmentData(departmentDataLabelCountryData);

    // Senority Data

    let senorityData = filterData.job
      ?.map((e) => {
        return { JOB_LEVEL: e.JOB_LEVEL, ORG_COUNT: e.ORG_COUNT };
      })
      .filter((ee) => ee.JOB_LEVEL !== "");

    const senorityDataLabel = senorityData?.map((e) => e.JOB_LEVEL);

    const senorityDataLabelDataLabelCountry = senorityData
      ?.map((e) => e.ORG_COUNT)
      .filter((ee) => ee !== "");

    // const senorityHoverLabel =
    //   senorityData &&
    //   Object.keys(senorityData).map(function (key) {
    //     const oo = senorityData[key]
    //       .filter((e) => e.Country)
    //       .reduce((prev, curr) => {
    //         prev[curr.Country] = (prev[curr.Country] || 0) + 1;
    //         return prev;
    //       }, {});

    //     return oo;
    //   });

    const senorityDataLabelCountryData = [
      {
        values: senorityDataLabelDataLabelCountry,
        labels: senorityDataLabel,
        hole: 0.4,
        type: "pie",
        textinfo: "value",
        textposition: "inside",
        sort: false,
        // text: Object.values(senorityHoverLabel).map((h) =>
        //   JSON.stringify(h)
        //     .replace(/[,]/g, "<br>")
        //     .replace(/[{}]/g, "")
        //     .replace(/["]/g, "")
        // ),
        hovertemplate: "<b>%{label}</b><extra></extra>",
      },
    ];

    setSeniorityDataData(senorityDataLabelCountryData);

    // Sub Industry Chart

    if (subindustryDataFilter.length) {
      const subsinds = filterData.sub_vertical_count
        ?.map((e) => {
          return { SUB_VERTICAL: e.SUB_VERTICAL, ORG_COUNT: e.ORG_COUNT };
        })
        .filter((ee) => ee.SUB_VERTICAL !== "");

      const subLabel = subsinds?.map((e) => e.SUB_VERTICAL);

      const subvalue = subsinds?.map((e) => e.ORG_COUNT);

      const subIndustrydataSelected = [
        {
          values: subvalue,
          labels: subLabel,
          hole: 0.4,
          type: "pie",
          textinfo: "value",
          textposition: "inside",
          domain: { column: 0 },
          sort: false,


          // customdata: subindustryHoverLabel2.map((e) => e.join("<br>")), // custom keys

          // text: subindustryHoverLabel.map((h) =>
          //   JSON.stringify(h)
          //     .replace(/[,]/g, "<br>")
          //     .replace(/[{}]/g, "")
          //     .replace(/["]/g, "")
          // ),

          hovertemplate: "<b> %{value}</b><extra></extra>",
        },
      ];

      setSubIndustryData(subIndustrydataSelected);

      // Activitity

      // Get unique count of sub industry by Industry

      const activity = filterData.activity_type_count
        ?.map((e) => {
          return { ACTIVITY_TYPE: e.ACTIVITY_TYPE, ORG_COUNT: e.ORG_COUNT };
        })
        .filter((ee) => ee.ACTIVITY_TYPE !== "");

      const subLabelActivity = activity?.map((e) => e.ACTIVITY_TYPE);

      const subvalueActivity = activity?.map((e) => e.ORG_COUNT);

      const activitySelected = [
        {
          values: subvalueActivity,
          labels: subLabelActivity,
          hole: 0.4,
          type: "pie",
          textinfo: "value",
          textposition: "inside",
          domain: { column: 0 },
          sort: false,

          // customdata: activityHoverLabel2.map((e) => e.join("<br>")), // custom keys

          // text: activityHoverLabel.map((h) =>
          //   JSON.stringify(h)
          //     .replace(/[,]/g, "<br>")
          //     .replace(/[{}]/g, "")
          //     .replace(/["]/g, "")
          // ),

          hovertemplate: "<b> %{label}</b> <extra></extra>",
        },
      ];

      setActivityTypeData(activitySelected);
    } else {
      setSubIndustryData([]);
    }
  }  

  }, [
    dispatch,   
    applyfilter
  ]);

  useEffect(() => {
    if(applyfilter){
      chartFun();   
      // setIsLoading(true)
      dispatch(loaderselected(true))

    }
   

  }, [
    chartFun,  
    applyfilter,
    dispatch
    
  ]);

  // On Industry Graph Click filter Sub Industry

  const filterSubIndust = async(inds) => {

    const filterData = await SubFilterDataRequest(
      countryData,
      [inds],
      subindustryDataFilter,
      activityDataFilter,
      companySizeDataFilter,
      departmentDataFilter,
      seniorityDataFilter,
      domain,
      std
    );
    setIsLoading(false)



    const subsinds = filterData.sub_vertical_count
        ?.map((e) => {
          return { SUB_VERTICAL: e.SUB_VERTICAL, ORG_COUNT: e.ORG_COUNT };
        })
        .filter((ee) => ee.SUB_VERTICAL !== "");

      const subLabel = subsinds?.map((e) => e.SUB_VERTICAL);

      const subvalue = subsinds?.map((e) => e.ORG_COUNT);

      const subIndustrydataSelected = [
        {
          values: subvalue,
          labels: subLabel,
          hole: 0.4,
          type: "pie",
          textinfo: "value",
          textposition: "inside",
          domain: { column: 0 },
          sort: false,

          // customdata: subindustryHoverLabel2.map((e) => e.join("<br>")), // custom keys

          // text: subindustryHoverLabel.map((h) =>
          //   JSON.stringify(h)
          //     .replace(/[,]/g, "<br>")
          //     .replace(/[{}]/g, "")
          //     .replace(/["]/g, "")
          // ),

          hovertemplate: "<b> %{value}</b><extra></extra>",
        },
      ];

      setSubIndustryData(subIndustrydataSelected);

      // Activitity

      // Get unique count of sub industry by Industry

      const activity = filterData.activity_type_count
        ?.map((e) => {
          return { ACTIVITY_TYPE: e.ACTIVITY_TYPE, ORG_COUNT: e.ORG_COUNT };
        })
        .filter((ee) => ee.ACTIVITY_TYPE !== "");

      const subLabelActivity = activity?.map((e) => e.ACTIVITY_TYPE);

      const subvalueActivity = activity?.map((e) => e.ORG_COUNT);

      const activitySelected = [
        {
          values: subvalueActivity,
          labels: subLabelActivity,
          hole: 0.4,
          type: "pie",
          textinfo: "value",
          textposition: "inside",
          domain: { column: 0 },
          sort: false,

          // customdata: activityHoverLabel2.map((e) => e.join("<br>")), // custom keys

          // text: activityHoverLabel.map((h) =>
          //   JSON.stringify(h)
          //     .replace(/[,]/g, "<br>")
          //     .replace(/[{}]/g, "")
          //     .replace(/["]/g, "")
          // ),

          hovertemplate: "<b> %{label}</b> <extra></extra>",
        },
      ];

      setActivityTypeData(activitySelected);

 
  };

 
  

  

  return (
    <div>{loader && <div> <Loader /> </div>}
    
    {!loader &&

    <div className="block"> 
      <div className="left">
        <div className="pie_chart">
          <div className="pie_design">
            <div className="heading">
              <h1>Company</h1>
            </div>
            <div className="box_pie">
              <div className="flex ">
                <div className="w-1/2 ">
                  <Plot
                    data={industryData}
                    onClick={(data) =>{ 
                      filterSubIndust(data.points[0]?.label);
                      setIsLoading(true)
                    }}
                    layout={{
                      width: 500,
                      hieght: 400,
                      showlegend: true,
                      margin: {
                        l: 0, // left margin
                        r: 35, // right margin
                      },
                      autosize: false,
                      backgroundcolor: "transparent",
                      paper_bgcolor: "transparent",
                      plot_bgcolor: "transparent",
                      title: {
                        text: "Industry",
                        font: {
                          family: "Arial",
                          size: 20,
                          color: "#145389",
                          weight: "bold",
                        },
                      },
                    }}
                    config={{
                      showLink: false,
                      displaylogo: false,
                      displayModeBar: false,
                    }}
                  />
                </div>
                <div className="w-1/2">
                  <Plot
                    data={companySize}
                    layout={{
                      width: 500,
                      hieght: 400,
                      
                      showlegend: true,
                      scrollZoom: true,
                      xaxis: {
                        automargin: true
                      },
                      yaxis: {
                        automargin: true
                      },
                      margin: {
                        l: 0, // left margin
                        r: 0, // right margin
                      },

                      autosize: false,
                      backgroundcolor: "transparent",
                      paper_bgcolor: "transparent",
                      plot_bgcolor: "transparent",
                      title: {
                        text: "Company Size",
                        font: {
                          family: "Arial",
                          size: 20,
                          color: "#145389",
                          weight: "bold",
                        },
                      },
                    }}
                    config={{
                      showLink: false,
                      displaylogo: false,
                      displayModeBar: false,
                    }}

                    // onClick={(data) => filterSubIndust(data.points[0]?.label)}
                  />
                </div>
              </div>
            </div>
          </div>
          {subIndustryData.length > 0 && (
            <div className="pie_chart">
              <div className="pie_design">
                <div className="box_pie">
                  {isLoading ? <Loader /> :
                  <div className="flex ">
                    <div className="w-1/2 ">
                      <Plot
                        data={subIndustryData}
                        layout={{
                          width: 500,
                          hieght: 400,
                          showlegend: true,
                          margin: {
                            l: 0, // left margin
                            r: 35, // right margin
                          },
                          autosize: false,
                          backgroundcolor: "transparent",
                          paper_bgcolor: "transparent",
                          plot_bgcolor: "transparent",
                          title: {
                            text: "Sub Industries",
                            font: {
                              family: "Arial",
                              size: 20,
                              color: "#145389",
                              weight: "bold",
                            },
                          },
                        }}
                        config={{
                          showLink: false,
                          displaylogo: false,
                          displayModeBar: false,
                        }}

                        //  onClick={(data) => filterSubIndust(data.points[0]?.label)}
                      />
                    </div>
                    <div className="w-1/2">
                      <Plot
                        data={activityTypeData}
                        layout={{
                          width: 500,
                          hieght: 400,
                          showlegend: true,
                          margin: {
                            l: 0, // left margin
                            r: 35, // right margin
                          },

                          autosize: false,
                          backgroundcolor: "transparent",
                          paper_bgcolor: "transparent",
                          plot_bgcolor: "transparent",
                          title: {
                            text: "Activity Type",
                            font: {
                              family: "Arial",
                              size: 20,
                              color: "#145389",
                              weight: "bold",
                            },
                          },
                        }}
                        config={{
                          showLink: false,
                          displaylogo: false,
                          displayModeBar: false,
                        }}

                        //   onClick={(data) => filterIndustry(data.points[0]?.label)}
                      />
                    </div>
                  </div>
}
                </div>
              </div>
            </div>
          )}
          <div className="pie_design">
            <div className="heading">
              <h1>Contacts</h1>
            </div>
            <div className="box_pie">
              <div className="flex ">
                <div className="w-1/2 ">
                  <Plot
                    data={departmentData}
                    layout={{
                      width: 500,
                      hieght: 400,
                      showlegend: true,
                      margin: {
                        l: 0, // left margin
                        r: 35, // right margin
                      },
                      autosize: false,
                      backgroundcolor: "transparent",
                      paper_bgcolor: "transparent",
                      plot_bgcolor: "transparent",
                      title: {
                        text: "Departments",
                        font: {
                          family: "Arial",
                          size: 20,
                          color: "#145389",
                          weight: "bold",
                        },
                      },
                    }}
                    config={{
                      showLink: false,
                      displaylogo: false,
                      displayModeBar: false,
                    }}

                    //   onClick={(data) => filterIndustry(data.points[0]?.label)}
                  />
                </div>
                <div className="w-1/2">
                  <Plot
                    data={seniorityData}
                    layout={{
                      width: 500,
                      hieght: 400,
                      showlegend: true,
                      margin: {
                        l: 0, // left margin
                        r: 35, // right margin
                      },

                      autosize: false,
                      backgroundcolor: "transparent",
                      paper_bgcolor: "transparent",
                      plot_bgcolor: "transparent",

                      title: {
                        text: "Job Level",
                        font: {
                          family: "Arial",
                          size: 20,
                          color: "#145389",
                          weight: "bold",
                        },
                      },
                    }}
                    config={{
                      showLink: false,
                      displaylogo: false,
                      displayModeBar: false,
                    }}

                    //   onClick={(data) => filterIndustry(data.points[0]?.label)}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* SubIndustry */}
        {/* 
        <div className="table_design">
          <div className="heading">
            <h1>Profiling Status</h1>
          </div>
          <div className="box_table">
            <div className="point">
              <p className="text">STD-Profiling</p>
              <p className="description">5000</p>
            </div>
            <div className="point">
              <p className="text">STD + M</p>
              <p className="description">3000</p>
            </div>
            <div className="point">
              <p className="text">Partial Profiled</p>
              <p className="description">7000</p>
            </div>
            <div className="point">
              <p className="text">Accounts - STD</p>
              <p className="description">5000</p>
            </div>
            <div className="point">
              <p className="text">Accounts - STD + M</p>
              <p className="description">3000</p>
            </div>
            <div className="point">
              <p className="text">STD Contacts/Account</p>
              <p className="description">3:1</p>
            </div>
          </div>
        </div> */}
      </div>

      <div className="asside_content">
        <div className="table_design">
          <div className="box_table">
            <div className="point_primary">
              LinkedIn<p></p>
              <p className="description_primary">5000</p>
            </div>
            <div className="headings">
              <p>Validation</p>
            </div>
            <div className="point">
              <p className="text">STD + M</p>
              <p className="description">3000</p>
            </div>
            <div className="point">
              <p className="text">Partial Profiled</p>
              <p className="description">7000</p>
            </div>
            <div className="point">
              <p className="text">Accounts - STD</p>
              <p className="description">5000</p>
            </div>
            <div className="point">
              <p className="text">Accounts - STD + M</p>
              <p className="description">3000</p>
            </div>
            <div className="point_secondary">
              <p className="text_secondary">STD Contacts/Account</p>
              <p className="description_secondary">3:1</p>
            </div>
            <div className="point_primary">
              <p className="text_primary">Mobile</p>
              <p className="description_primary">5000</p>
            </div>
            <div className="point_primary">
              <p className="text_primary">LinkedIn</p>
              <p className="description_primary">5000</p>
            </div>
            <div className="point_primary">
              <p className="text_primary">Email</p>
              <p className="description_primary">3000</p>
            </div>
            <div className="point_primary">
              <p className="text_primary">Mobile</p>
              <p className="description_primary">7000</p>
            </div>
            <div className="headings">
              <p>Validation</p>
            </div>
            <div className="point">
              <p className="text">STD + M</p>
              <p className="description">3000</p>
            </div>
            <div className="point">
              <p className="text">Partial Profiled</p>
              <p className="description">7000</p>
            </div>
            <div className="point">
              <p className="text">Accounts - STD</p>
              <p className="description">5000</p>
            </div>
            <div className="point">
              <p className="text">Accounts - STD + M</p>
              <p className="description">3000</p>
            </div>
          </div>
        </div>
      </div>
      </div>
}
    </div>
   
  );
}

