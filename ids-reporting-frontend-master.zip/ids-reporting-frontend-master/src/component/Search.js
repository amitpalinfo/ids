import React from "react";

export default function Search() {
  return (
    <div class="unavailable_search">
      <div class="search_inner">
        <img src="./assets/search no result.png" alt="" />
        <p class="search_text">
          Provide your search criteria to find contacts
        </p>
      </div>
    </div>
  );
}
